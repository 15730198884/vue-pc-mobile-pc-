<template>
    <div>mobile</div>
</template>

<script>
export default {
  name: 'mobilePage'
}
</script>

<style scoped>

</style>
