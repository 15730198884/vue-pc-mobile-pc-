import Vue from 'vue'

/* eslint-disable no-new */
new Vue({
  el: '#app'
})
